

# 甲乙丙丁的硫含量分别是（单位：%）
S_jia = 3
S_yi = 1
S_bing = 2
S_ding = 1

# 甲乙丙丁的进货价格（单位：千元/t）
JG_jia = 6
JG_yi = 16
JG_bing = 10
JG_ding = 15

# 产品AB硫含量的上限（单位：%）
S_A = 2.5
S_B = 1.5

# 产品AB的售价（单位：千元/t）
JG_A = 9
JG_B = 15

# 甲乙丙丁的供货量上限(单位：t)
max_ding = 50

# 产品AB的市场需求（单位：t）
ShiChang_A = 100
ShiChang_B = 200

